package game.view;

public interface PuzzleView {
    void repaintGame(int movesCount);

    void congratulateTheWinner();

}
