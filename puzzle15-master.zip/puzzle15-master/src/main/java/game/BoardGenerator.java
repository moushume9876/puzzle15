package game;

public interface BoardGenerator {

    int[] generateVector(int boardSize);
}
